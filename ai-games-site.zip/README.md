# AI Arcade (Static Site)

A minimal, fast static website to embed AI-based games (via iframe) and host a local AI Tic‑Tac‑Toe powered by the minimax algorithm.

## Quick start

1. **Download** this repo as a ZIP and unzip it.
2. **Preview locally**: open `index.html` in your browser (or run a tiny server).
3. **Deploy** in minutes:
   - **Vercel**: drag-and-drop the folder at vercel.com/new or run:
     ```bash
     npm i -g vercel
     vercel deploy --prod
     ```
   - **Netlify**: drop the folder on app.netlify.com/drop
   - **GitHub Pages**: push to a repo and enable Pages (root, main branch).

## Add your own games

Open **games.json** and add entries:
```json
{
  "title": "My AI Game",
  "description": "Short pitch",
  "tag": "LLM",
  "thumb": "assets/placeholder.png",
  "embedUrl": "https://your-embeddable-url.example", 
  "playUrl": "https://same-or-direct-link",
  "source": "https://project-homepage.example"
}
```

> **Note:** Some sites block iframes (X-Frame-Options/COEP). If an embed fails, the modal will show blank. Use the **Open in new tab** button as a fallback or host games on platforms that allow embedding (itch.io embed widgets, many Hugging Face Spaces, your own domain).

## Local AI game included

- `games/tictactoe/index.html` uses **minimax with alpha‑beta pruning** to play perfect Tic‑Tac‑Toe.
- Thumbnail at `assets/tictactoe-thumb.png`.

## Customize

- Edit **styles.css** for colors/typography.
- Replace the logo text in **index.html** header.
- Add analytics (e.g., Plausible) by inserting their script tag in `index.html`.
- Add a favicon to `/assets` and link it in `<head>`.

## Dev tips

Run a small local server for CORS-friendly testing:
```bash
# Python 3
python -m http.server 8080
# then visit http://localhost:8080
```

## License

MIT. Use anywhere.
