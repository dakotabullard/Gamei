/* Load games from games.json and wire up modal embed */
const grid = document.getElementById('grid');
const modal = document.getElementById('modal');
const gameFrame = document.getElementById('gameFrame');
const closeModal = document.getElementById('closeModal');
const openNewTab = document.getElementById('openNewTab');
const fullscreenBtn = document.getElementById('fullscreenBtn');
const year = document.getElementById('year');
year.textContent = new Date().getFullYear();

const cardTpl = document.getElementById('cardTemplate');

let currentGame = null;

fetch('games.json')
  .then(r => r.json())
  .then(data => {
    data.games.forEach(addCard);
  })
  .catch(err => {
    console.error('Failed to load games.json', err);
    grid.innerHTML = '<p style="opacity:.8">Could not load games.</p>';
  });

function addCard(game){
  const node = cardTpl.content.cloneNode(true);
  node.querySelector('.thumb').src = game.thumb || 'assets/placeholder.png';
  node.querySelector('.thumb').alt = game.title;
  node.querySelector('.title').textContent = game.title;
  node.querySelector('.desc').textContent = game.description || '';
  node.querySelector('.badge').textContent = game.tag || 'AI';
  const playBtn = node.querySelector('.play');
  const srcBtn = node.querySelector('.outline');
  srcBtn.href = game.source || '#';
  srcBtn.textContent = game.source ? 'Source' : 'Details';
  playBtn.addEventListener('click', () => openGame(game));
  grid.appendChild(node);
}

function openGame(game){
  currentGame = game;
  modal.setAttribute('aria-hidden', 'false');
  gameFrame.src = game.embedUrl;
  openNewTab.href = game.playUrl || game.embedUrl;
}

function closeGame(){
  modal.setAttribute('aria-hidden', 'true');
  gameFrame.src = 'about:blank';
  currentGame = null;
}

closeModal.addEventListener('click', closeGame);
document.getElementById('backdrop').addEventListener('click', closeGame);
document.addEventListener('keydown', (e)=>{
  if(e.key === 'Escape') closeGame();
});

fullscreenBtn.addEventListener('click', () => {
  const el = gameFrame;
  if (el.requestFullscreen) el.requestFullscreen();
  else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
  else if (el.msRequestFullscreen) el.msRequestFullscreen();
});
